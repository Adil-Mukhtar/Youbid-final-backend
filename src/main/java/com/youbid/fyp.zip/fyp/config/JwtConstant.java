package com.youbid.fyp.config;

public class JwtConstant {

    public static String JWT_HEADER = "Authorization";
    public static String SECRET_KEY = "aweifoaj932omasdwoqfasEDQRADASDAASADadqwodIMDOw09234242"; //random string to validate and generate token
}
